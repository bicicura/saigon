<?php return array (
  'casting-carusel' => 'App\\Http\\Livewire\\CastingCarusel',
  'casting-group' => 'App\\Http\\Livewire\\CastingGroup',
  'casting-list' => 'App\\Http\\Livewire\\CastingList',
  'create-actor' => 'App\\Http\\Livewire\\CreateActor',
  'create-post' => 'App\\Http\\Livewire\\CreatePost',
  'edit-fotografias' => 'App\\Http\\Livewire\\EditFotografias',
  'export-button' => 'App\\Http\\Livewire\\ExportButton',
  'management-table' => 'App\\Http\\Livewire\\ManagementTable',
  'nav-form' => 'App\\Http\\Livewire\\NavForm',
  'panel-table' => 'App\\Http\\Livewire\\PanelTable',
  'table-inbox' => 'App\\Http\\Livewire\\TableInbox',
);