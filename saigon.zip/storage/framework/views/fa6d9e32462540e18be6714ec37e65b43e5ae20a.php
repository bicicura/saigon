<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="text-xl font-semibold leading-tight text-gray-800">
            Editar Casting: <?php echo e($casting['nombre']); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('create-post', 
        [
            'type' => 'update',
            'casting' => $casting,
            'seccion' => $casting['seccion'],
            'nombre' => $casting['nombre'],
            'productora' => $casting['productora'],
            'director' => $casting['director'],
            'categoria' => $casting['categoria'],
            'video_url' => $casting['url'],
            'avatarActual' => $casting['thumbnail'],
        ])->html();
} elseif ($_instance->childHasBeenRendered('pvGRjC6')) {
    $componentId = $_instance->getRenderedChildComponentId('pvGRjC6');
    $componentTag = $_instance->getRenderedChildComponentTagName('pvGRjC6');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('pvGRjC6');
} else {
    $response = \Livewire\Livewire::mount('create-post', 
        [
            'type' => 'update',
            'casting' => $casting,
            'seccion' => $casting['seccion'],
            'nombre' => $casting['nombre'],
            'productora' => $casting['productora'],
            'director' => $casting['director'],
            'categoria' => $casting['categoria'],
            'video_url' => $casting['url'],
            'avatarActual' => $casting['thumbnail'],
        ]);
    $html = $response->html();
    $_instance->logRenderedChild('pvGRjC6', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>;
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH D:\xampp\htdocs\saigon\resources\views/panel/edit.blade.php ENDPATH**/ ?>