

<?php $__env->startSection('content'); ?>

<style>
    @media (min-width: 40em) { .hero-p-w { width: 65%; } }

    img {
  display: block;
  width: auto;
  height: 90%;
  /* margin: 0 auto; */
}

main {
    height: calc(100vh - 6rem)
}
</style>

<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.desktop-nav-fixed','data' => []]); ?>
<?php $component->withName('desktop-nav-fixed'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

<section class="px-3.5 lg:pr-16 lg:pl-10 flex flex-col-reverse mt-24 lg:flex-row justify-between mb-12 lg:mb-0 saigon-text-300 h-full">

   <div class="grid h-full grid-cols-3 ml-auto">
    <div></div>
    <div>
        <div class="w-full h-full">
            <img class="object-cover w-full rounded-2xl" src="imgs/managment/2.jpg" alt="">
            <div class="flex justify-between">
                <button>←</button>
                <button>→</button>
            </div>
        </div>
    </div>

    <div class="text-right">
        <p>Florencia Baptista</p>
        <p>Edad: 25 años</p>
        <p>Nacionalidad: Argentina</p>
        <p>Altura: 156 cm</p>
        <p>IMDDB | IG | C.V.</p>
        <div x-data="{selected:null}">
            <ul>
                <li class="relative">
                    <button type="button" class="w-full text-right" @click="selected !== 1 ? selected = 1 : selected = null">
                        <div class="w-full transition-all">
                            <span >Bio</span>
                        </div>
                    </button>
        
                    <div class="relative overflow-hidden text-gray-500 transition-all duration-700 max-h-0" style="" x-ref="container1" x-bind:style="selected == 1 ? 'max-height: ' + $refs.container1.scrollHeight + 'px' : ''">
                        <div style="max-width: 35ch; margin-left: auto;" class="py-2 text-right h-fit saigon-text-200">
                            It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).
                        </div>
                    </div>
                </li>
            </ul>
        </div>
        <p>Videos</p>

    </div>

   </div>

</section>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\saigon\resources\views/managment-detail.blade.php ENDPATH**/ ?>