

<?php $__env->startSection('content'); ?>

<?php $__env->startSection('title'); ?> <?php echo e('— ' . __('Fotografía')); ?> <?php $__env->stopSection(); ?>

<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.desktop-nav-fixed','data' => []]); ?>
<?php $component->withName('desktop-nav-fixed'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@splidejs/splide@3.6.12/dist/css/splide.min.css">
<style>
    .splide__arrow {
        background: none
    }

    .splide__arrow { 
        height: fit-content;
        transform: translate(0%)
    }

    .carusel-img {
        min-height: 28rem;
        width: 100%;
        object-fit: cover
    }
</style>

<section id="scroll-target" data-scroll data-scroll-target class="smooth-scroll px-3.5 lg:pr-16 lg:pl-10 flex flex-col-reverse lg:flex-row justify-between lg:gap-0 lg:pb-36 pb-24">
    
    <div class="mt-20 space-y-20 lg:space-y-10 lg:mt-28 lg:w-10/12">
        <?php $__currentLoopData = $castings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.fotografia-slider','data' => ['item' => $item]]); ?>
<?php $component->withName('fotografia-slider'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['item' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($item)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div data-scroll data-scroll-sticky data-scroll-target="#scroll-target" class="flex flex-col items-end gap-4 mt-32 text-right lg:top-12 lg:sticky lg:right-0 lg:gap-10 lg:mt-20 lg:w-8/12 lg:h-fit lg:z-10"">
        <h1 class="uppercase saigon-text-5xl saigon-font-thin saigon-title-line-height"><?php echo e(__("Fotografía")); ?></h1>
        <div  class="saigon-text-300 saigon-p-line-height" style="width: 35rem;">
            <p><?php echo e(__("En nuestros casting fotográficos, cubrimos proyectos de moda, publicidad, catalogo, social media, corporativo, branding y todo el campo del medio gráfico y digital.")); ?></p>
            <br>
            <p><?php echo e(__("Nuestros fotógrafos trabajan optimizando recursos - técnicos y creativos - para lograr los objetivos de cada proyecto.")); ?></p>
            <br>
            <p><?php echo e(__("Le ponemos los cuerpos los rostros a tus ideas y proyectos.")); ?></p>
            <?php if(app()->getLocale() === "es"): ?>
                <br>    
                <p>La luz y el movimiento son el juego y nos encanta jugar.</p>
            <?php endif; ?>
            <br>
            <div>
                <p class="uppercase"><?php echo e(__("Contacto")); ?>:</p>
                <p>Andi di Napoli  |  andi@saigonbuenosaires.com</p>
                <p>Javier Daniel  |  javier@saigonbuenosaires.com</p>
            </div>
        </div>
    </div>
</section>

<script src="https://cdn.jsdelivr.net/npm/@splidejs/splide@3.6.12/dist/js/splide.min.js"></script>

<script>
    document.addEventListener( 'DOMContentLoaded', function() {
        document.querySelectorAll('.splide').forEach(carousel => new Splide( carousel, {
            perPage: 1,
            pagination: false,
        } ).mount());
    } );
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\saigon\resources\views/fotografia.blade.php ENDPATH**/ ?>