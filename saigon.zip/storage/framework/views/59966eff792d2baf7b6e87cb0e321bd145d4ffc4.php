<div class="lg:w-full h-fit">
    <div class="flex items-center gap-4 mb-2">
        <label class="ml-auto uppercase cursor-pointer lg:ml-0" for="<?php echo e($inputContent['model']); ?>"><?php echo e(__($inputContent['label'])); ?></label>
        <?php $__errorArgs = [$inputContent['model']];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="mt-1 text-sm font-bold text-red-500"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    
    <input 
    wire:model="<?php echo e($inputContent['model']); ?>" 
    <?php echo e(isset($attributes['x-mask']) ? 'x-mask=9999/99/99 placeholder=AAAA/MM/DD' : ''); ?>

    id="<?php echo e($inputContent['model']); ?>" 
    type="text" 
    class="w-full text-right text-white bg-transparent lg:text-left focus:ring-0">
</div>

<?php /**PATH D:\xampp\htdocs\saigon\resources\views/components/input/nav-input-text.blade.php ENDPATH**/ ?>