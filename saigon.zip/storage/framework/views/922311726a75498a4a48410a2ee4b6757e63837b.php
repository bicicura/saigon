
<div class="splide">
    <div class="flex items-center justify-between mb-2 saigon-text-500 splide__arrows">
        <p class="leading-none transition lg:line-clamp-1 lg:hover:line-clamp-none"><span class="uppercase"><?php echo e($casting['nombre']); ?></span><span> — <?php echo e($casting['director']); ?></span><span> | <?php echo e($casting['productora']); ?></span></p>
        <div class="flex ml-auto w-max">
            <button style="position: static" class="splide__arrow splide__arrow--prev saigon-font-light">
                <
            </button>
            <button style="position: static" class="splide__arrow splide__arrow--next saigon-font-light">
                >
            </button>
        </div>
    </div>

    <div class="overflow-hidden splide__track aspect-video rounded-2xl">
          <ul class="splide__list">
                <?php $__currentLoopData = $casting->getFotografias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="splide__slide">
                    <img class="object-contain object-center w-full h-full cursor-grab rounded-2xl carusel-img" src="/fotos/<?php echo e($foto->img); ?>" alt="">
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
    </div>
  </div>
  
  
  
  <?php /**PATH D:\xampp\htdocs\saigon\resources\views/components/fotografia-slider.blade.php ENDPATH**/ ?>