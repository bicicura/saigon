

<?php $__env->startSection('title'); ?> <?php echo e('— ' . __('Ficción')); ?> <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.desktop-nav-fixed','data' => []]); ?>
<?php $component->withName('desktop-nav-fixed'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

<style>
    .carusel-img {
        min-height: 28rem;
        width: 100%;
        object-fit: cover
    }

    @media (min-width: 40em) { 
        
        .hero-p-w { width: 77%; } 

    }
</style>

<div class="smooth-scroll">
    <section class="px-3.5 lg:pr-16 lg:pl-8 flex flex-col-reverse lg:flex-row justify-between mb-12 w-full">

        <div class="flex flex-col gap-4 mt-32 lg:gap-8 lg:mt-32">
            <h1 class="tracking-tight uppercase saigon-text-5xl saigon-font-thin saigon-title-line-height"><?php echo e(__("Ficción")); ?></h1>
            <div class="flex flex-col w-full gap-5 lg:text-xl hero-p-w">
                <div>
                    <p><?php echo e(__("Un espacio dedicado al diseño de casting moderno y de dedicación creativa.")); ?></p>
                    <p><?php echo e(__("Cubrimos el medio audiovisual en su espectro más artístico: cine, series, televisión , voz original, video clip, video arte, fashion film, transmedia.")); ?></p>
                </div>
                <div>
                    <p><?php echo e(__("Componemos un mapa de acción para formar elencos que se articulen a cada propósito.")); ?></p>
                    <p><?php echo e(__("Damos relieve a las historias que nos toca contar desde las actuaciones y los ensambles de talentos.")); ?></p>
                </div>
                <div>
                    <p><?php echo e(__("Enfocar la búsqueda, proponer opciones originales y efectivas, son nuestra prioridad.")); ?></p>
                    <p><?php echo e(__("Vemos en los proyectos lo que nadie vio todavía para materializarlos a través acciones propias y eficaces.")); ?></p>
                </div>
                <div>
                    <p><?php echo e(__("La ficción en Saigón es nuestra nueva realidad potenciando nuestra experiencia y pasión.")); ?></p>
                </div>
                <div>
                    <p><?php echo e(__("Contacto")); ?>:</p>
                    <p>Pablo Lapa |  lapa@saigonbuenosaires.com</p>
                </div>
            </div>
        </div>
    
    </section>
    
    <div class="px-3.5 lg:pr-16 lg:pl-10 lg:mt-0">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('casting-list', ['seccion' => $seccion])->html();
} elseif ($_instance->childHasBeenRendered('YlK1JEQ')) {
    $componentId = $_instance->getRenderedChildComponentId('YlK1JEQ');
    $componentTag = $_instance->getRenderedChildComponentTagName('YlK1JEQ');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('YlK1JEQ');
} else {
    $response = \Livewire\Livewire::mount('casting-list', ['seccion' => $seccion]);
    $html = $response->html();
    $_instance->logRenderedChild('YlK1JEQ', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\saigon\resources\views/ficcion.blade.php ENDPATH**/ ?>