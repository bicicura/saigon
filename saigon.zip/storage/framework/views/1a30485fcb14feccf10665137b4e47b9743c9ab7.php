

<?php $__env->startSection('title'); ?> <?php echo e('— ' . __('Ficción')); ?> <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@splidejs/splide@3.6.12/dist/css/splide.min.css">

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('casting-carusel', ['seccion' => $seccion])->html();
} elseif ($_instance->childHasBeenRendered('jip7a5L')) {
    $componentId = $_instance->getRenderedChildComponentId('jip7a5L');
    $componentTag = $_instance->getRenderedChildComponentTagName('jip7a5L');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('jip7a5L');
} else {
    $response = \Livewire\Livewire::mount('casting-carusel', ['seccion' => $seccion]);
    $html = $response->html();
    $_instance->logRenderedChild('jip7a5L', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<script src="https://cdn.jsdelivr.net/npm/@splidejs/splide@3.6.12/dist/js/splide.min.js"></script>

<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.desktop-nav-fixed','data' => []]); ?>
<?php $component->withName('desktop-nav-fixed'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

<style>
    .splide__arrow {
        background: none
    }

    .splide__arrow { 
        height: fit-content;
        transform: translate(0%)
    }

    .carusel-img {
        min-height: 28rem;
        width: 100%;
        object-fit: cover
    }

    .splide__arrow {
        position: static!important;
        display: flex!important;
        justify-content: center!important;
        background: none!important;
        top: unset!important;
        bottom: -.5rem!important;
        color: black!important;
        width: unset!important;
    }

    .splide__arrow--prev {
    left: 0!important
}

.splide__arrow--next {
    right: 0!important
}


    @media (min-width: 40em) { 
        
        .hero-p-w { 
            width: 77%;
        
        } 

        .hero-p-w div p {
            line-height: 1.6rem;
        }

    }
</style>

<div class="smooth-scroll">
    <section class="px-3.5 lg:pr-16 lg:pl-8 flex flex-col-reverse lg:flex-row justify-between mb-12 w-full">

        <div class="flex flex-col gap-4 mt-32 lg:gap-6 lg:mt-26">
            <h1 class="tracking-tight uppercase saigon-text-5xl saigon-font-thin saigon-title-line-height"><?php echo e(__("Ficción")); ?></h1>
            <div class="flex flex-col w-full gap-5 lg:text-xl hero-p-w">
                <div>
                    <p><?php echo e(__("Un espacio dedicado al diseño de casting moderno y de dedicación creativa.")); ?></p>
                    <p><?php echo e(__("Cubrimos el medio audiovisual en su espectro más artístico: cine, series, televisión , voz original, video clip, video arte, fashion film, transmedia.")); ?></p>
                </div>
                <div>
                    <p><?php echo e(__("Componemos un mapa de acción para formar elencos que se articulen a cada propósito.")); ?></p>
                    <p><?php echo e(__("Damos relieve a las historias que nos toca contar desde las actuaciones y los ensambles de talentos.")); ?></p>
                </div>
                <div>
                    <p><?php echo e(__("Enfocar la búsqueda, proponer opciones originales y efectivas, son nuestra prioridad.")); ?></p>
                    <p><?php echo e(__("Vemos en los proyectos lo que nadie vio todavía para materializarlos a través acciones propias y eficaces.")); ?></p>
                </div>
                <div>
                    <p><?php echo e(__("La ficción en Saigón es nuestra nueva realidad potenciando nuestra experiencia y pasión.")); ?></p>
                </div>
                <div>
                    <p class="uppercase"><?php echo e(__('Contacto')); ?>:</p>
                    <p><span class="block lg:inline">Pablo Lapa</span><span class="hidden lg:inline lg:mx-1">  |  </span><span class="block lg:inline">lapa@saigonbuenosaires.com</span></p>
                </div>
            </div>
        </div>
    
    </section>
    
    <div class="px-3.5 lg:pr-16 lg:pl-10 lg:mt-0">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('casting-list', ['seccion' => $seccion])->html();
} elseif ($_instance->childHasBeenRendered('FOfbiKL')) {
    $componentId = $_instance->getRenderedChildComponentId('FOfbiKL');
    $componentTag = $_instance->getRenderedChildComponentTagName('FOfbiKL');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('FOfbiKL');
} else {
    $response = \Livewire\Livewire::mount('casting-list', ['seccion' => $seccion]);
    $html = $response->html();
    $_instance->logRenderedChild('FOfbiKL', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>    
    
</div>

<script defer>
    window.addEventListener('build', function (e) { 
        console.log('se disparo')
        var splide = new Splide( '.splide', {
            perPage: 1,
            arrows: true,
            pagination: false,
        } );
        
        splide.mount();
     }, false);
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\saigon\resources\views/ficcion.blade.php ENDPATH**/ ?>