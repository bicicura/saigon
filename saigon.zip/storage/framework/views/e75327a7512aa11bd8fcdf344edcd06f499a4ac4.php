

<?php $__env->startSection('content'); ?>

<style>
    @media (min-width: 40em) { .hero-p-w { width: 60%; } }
</style>

<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.desktop-nav-fixed','data' => []]); ?>
<?php $component->withName('desktop-nav-fixed'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

<div class="smooth-scroll">
    <section class="px-3.5 lg:pr-16 lg:pl-10 flex flex-col-reverse lg:flex-row justify-between mb-12 lg:mb-0">t
        <div class="z-20 flex flex-col items-end gap-4 mt-32 text-right lg:ml-auto lg:gap-8 lg:mt-16">
            <h1 style="width: min-content;" class="tracking-tight saigon-text-5xl saigon-font-thin saigon-title-line-height">MANAGMENT</h1>
            <div class="w-full text-xl  saigon-p-line-height hero-p-w">
                <p>Gestionar carreras actorales es un punto de diferencia que está impulsando el crecimiento Saigón.</p>
                <p>La meta central es propulsar el potencial de talentos exclusivos - con experiencia y nóveles - para que estén disponibles en los roles y proyectos a su medida.</p>
                <br>
                <p>Brindamos un servicio profesional dirigido a casting directors, productoras y realizadores.</p>
                <br>
                <div class="w-11/12 ml-auto">
                    <p>Actualizamos el intercambio entre nuestros representados y nuestros clientes para generar una comunicación fluida y una transformación en las formas de trabajo ya establecidas.</p>
                </div>
                <br>
                <div>
                    <p>CONTACTO:</p>
                    <p>Julian Krakov |  julian@saigonbuenosaires.com</p>
                </div>
            </div>
        </div>
    
    </section>
    
    <section class="px-3.5 lg:pr-16 lg:pl-10 pt-20 lg:mt-0 pb-8">
    
        <div class="grid grid-cols-4 gap-6">
            <a href="/managment-detail">
                <div style="height: 26rem" class="w-full">
                    <img class="object-cover w-full h-full rounded-xl" src="imgs/managment/1.jpg" alt="">
                </div>
                <p class="saigon-text-200">Axl Rosa</p>
            </a>
            <a href="/managment-detail">
                <div style="height: 26rem" class="w-full">
                    <img class="object-cover w-full h-full rounded-xl" src="imgs/managment/2.jpg" alt="">
                </div>
                <p class="saigon-text-200">Florencia Baptista</p>
            </a>
            <a href="/managment-detail">
                <div style="height: 26rem" class="w-full">
                    <img class="object-cover w-full h-full rounded-xl" src="imgs/managment/3.jpg" alt="">
                </div>
                <p class="saigon-text-200">Ana Revolver</p>
            </a>
            <a href="/managment-detail">
                <div style="height: 26rem" class="w-full">
                    <img class="object-cover w-full h-full rounded-xl" src="imgs/managment/4.jpg" alt="">
                </div>
                <p class="saigon-text-200">Juan West</p>
            </a>
            <a href="/managment-detail">
                <div style="height: 26rem" class="w-full">
                    <img class="object-cover w-full h-full rounded-xl" src="imgs/managment/5.jpg" alt="">
                </div>
                <p class="saigon-text-200">Gloria Amor</p>
            </a>
            <a href="/managment-detail">
                <div style="height: 26rem" class="w-full">
                    <img class="object-cover w-full h-full rounded-xl" src="imgs/managment/6.jpg" alt="">
                </div>
                <p class="saigon-text-200">Fiona Manzana</p>
            </a>
            <a href="/managment-detail">
                <div style="height: 26rem" class="w-full">
                    <img class="object-cover w-full h-full rounded-xl" src="imgs/managment/7.jpg" alt="">
                </div>
                <p class="saigon-text-200">Joni Young</p>
            </a>
            <a href="/managment-detail">
                <div style="height: 26rem" class="w-full">
                    <img class="object-cover w-full h-full rounded-xl" src="imgs/managment/8.jpg" alt="">
                </div>
                <p class="saigon-text-200">Ariel Rosa</p>
            </a>
        </div>
    
    </section>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\saigon\resources\views/managment.blade.php ENDPATH**/ ?>