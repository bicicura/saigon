<form wire:submit.prevent="submit" class="w-full pb-12 space-y-6 text-xl text-white saigon-text-200 lg:pb-0 lg:space-y-0 lg:flex lg:justify-between lg:flex-col saigon-font-thin px-7 lg:px-0 lg:mt-12 lg:pr-16 lg:w-full nav-form-height">

    <div class="space-y-6 lg:grid lg:grid-cols-3 lg:space-y-0 lg:gap-12 lg:w-full">
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input.nav-input-text','data' => ['inputContent' => ['label' => 'Nombre y Apellido', 'model' => 'nombre' ]]]); ?>
<?php $component->withName('input.nav-input-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['inputContent' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['label' => 'Nombre y Apellido', 'model' => 'nombre' ])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input.nav-input-text','data' => ['inputContent' => ['label' => 'Email', 'model' => 'email', 'model' => 'email']]]); ?>
<?php $component->withName('input.nav-input-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['inputContent' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['label' => 'Email', 'model' => 'email', 'model' => 'email'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    </div>
    
    <div class="space-y-6 lg:grid lg:grid-cols-3 lg:space-y-0 lg:gap-12 lg:w-full">
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input.nav-input-text','data' => ['inputContent' => ['label' => 'Celular', 'model' => 'celular']]]); ?>
<?php $component->withName('input.nav-input-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['inputContent' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['label' => 'Celular', 'model' => 'celular'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input.nav-input-text-legend','data' => ['inputContent' => ['label' => 'DNI', 'legend' => '(El número no debe incluír guiones ni puntos. Ej: 302002009)', 'model' => 'dni']]]); ?>
<?php $component->withName('input.nav-input-text-legend'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['inputContent' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['label' => 'DNI', 'legend' => '(El número no debe incluír guiones ni puntos. Ej: 302002009)', 'model' => 'dni'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input.nav-input-text','data' => ['inputContent' => ['label' => 'Nacionalidad', 'model' => 'nacionalidad']]]); ?>
<?php $component->withName('input.nav-input-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['inputContent' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['label' => 'Nacionalidad', 'model' => 'nacionalidad'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    </div>
    
    <div class="items-baseline lg:grid lg:grid-cols-3 lg:gap-12" x-data="{ cuitIsEmpty: false }">
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input.nav-input-text-legend','data' => ['inputContent' => ['label' => 'CUIT', 'legend' => '(El número no debe incluír guiones ni puntos. Ej: 302002009)', 'model' => 'cuit']]]); ?>
<?php $component->withName('input.nav-input-text-legend'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['inputContent' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['label' => 'CUIT', 'legend' => '(El número no debe incluír guiones ni puntos. Ej: 302002009)', 'model' => 'cuit'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        <div class="gap-4 pt-3 ml-auto space-x-4 lg:space-x-0 w-max lg:ml-0 lg:pt-0 lg:w-full lg:flex lg:items-center">
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input.nav-checkbox','data' => ['inputContent' => ['label' => 'No poseo', 'model' => 'cuit']]]); ?>
<?php $component->withName('input.nav-checkbox'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['inputContent' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['label' => 'No poseo', 'model' => 'cuit'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        </div>
    </div>

    <div class="flex items-center gap-4 lg:w-max">
        <div class="flex items-center justify-between w-full gap-6 pt-2 lg:pt-0 lg:justify-start lg:gap-12">
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input.nav-checkbox','data' => ['reverse' => 'flex-row-reverse lg:flex-row','inputContent' => ['label' => 'Femenino', 'model' => 'sexo']]]); ?>
<?php $component->withName('input.nav-checkbox'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['reverse' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('flex-row-reverse lg:flex-row'),'inputContent' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['label' => 'Femenino', 'model' => 'sexo'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input.nav-checkbox','data' => ['reverse' => 'flex-row-reverse lg:flex-row','inputContent' => ['label' => 'Masculino', 'model' => 'sexo']]]); ?>
<?php $component->withName('input.nav-checkbox'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['reverse' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('flex-row-reverse lg:flex-row'),'inputContent' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['label' => 'Masculino', 'model' => 'sexo'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input.nav-checkbox','data' => ['reverse' => 'flex-row-reverse lg:flex-row','inputContent' => ['label' => 'Otro', 'model' => 'sexo']]]); ?>
<?php $component->withName('input.nav-checkbox'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['reverse' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('flex-row-reverse lg:flex-row'),'inputContent' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['label' => 'Otro', 'model' => 'sexo'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        </div>
        <?php $__errorArgs = ['sexo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="w-full text-sm font-bold text-red-500 rounded-full"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="space-y-6 lg:grid lg:grid-cols-3 lg:space-y-0 lg:gap-12">
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input.nav-input-text','data' => ['xMask' => '99/99/9999','placeholder' => 'MM/DD/YYYY','inputContent' => ['label' => 'FECHA DE NACIMIENTO', 'model' => 'nacimiento']]]); ?>
<?php $component->withName('input.nav-input-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['x-mask' => '99/99/9999','placeholder' => 'MM/DD/YYYY','inputContent' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['label' => 'FECHA DE NACIMIENTO', 'model' => 'nacimiento'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input.nav-input-text','data' => ['inputContent' => ['label' => 'Altura', 'model' => 'altura']]]); ?>
<?php $component->withName('input.nav-input-text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['inputContent' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['label' => 'Altura', 'model' => 'altura'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    </div>
    
    <div class="grid gap-12 lg:gap-12 lg:grid-cols-3 lg:pt-3">
        <div class="flex flex-col gap-6 lg:col-span-2 lg:grid-cols-3 lg:grid">
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input.nav-select','data' => ['inputContent' => ['label' => 'Talle remera', 'model' => 'remera', 'options' => ['Small' => 'Small', 'Medium' => 'Medium', 'Large' => 'Large', ]]]]); ?>
<?php $component->withName('input.nav-select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['inputContent' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['label' => 'Talle remera', 'model' => 'remera', 'options' => ['Small' => 'Small', 'Medium' => 'Medium', 'Large' => 'Large', ]])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input.nav-select','data' => ['inputContent' => ['label' => 'Talle pantalon', 'model' => 'pantalon', 'options' => ['Small' => 'Small', 'Medium' => 'Medium', 'Large' => 'Large', ]]]]); ?>
<?php $component->withName('input.nav-select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['inputContent' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['label' => 'Talle pantalon', 'model' => 'pantalon', 'options' => ['Small' => 'Small', 'Medium' => 'Medium', 'Large' => 'Large', ]])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input.nav-select','data' => ['inputContent' => ['label' => 'Talle calzado', 'model' => 'calzado', 'options' => ['Small' => 'Small', 'Medium' => 'Medium', 'Large' => 'Large', ]]]]); ?>
<?php $component->withName('input.nav-select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['inputContent' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['label' => 'Talle calzado', 'model' => 'calzado', 'options' => ['Small' => 'Small', 'Medium' => 'Medium', 'Large' => 'Large', ]])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        </div>
    </div>
    
    <div class="grid gap-12 lg:gap-12 lg:grid-cols-3 lg:pt-3">
        <div class="flex gap-6 lg:col-span-2 lg:grid-cols-3 lg:grid">
            <div class="hidden lg:block"></div>
            <div class="hidden lg:block"></div>
            <div class="w-full h-fit" x-data=" { open: false, } " @close-skills.window="open = false">
                <button
                @click="$dispatch('skills-flag'); open = !open;"
                type="button"
                class="w-full text-left text-white bg-transparent bg-right bg-no-repeat border-b border-white skills-container">SKILLS</button>
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.skills-container','data' => []]); ?>
<?php $component->withName('skills-container'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>            
            </div>
        </div>
    </div>

    

    <div class="grid gap-12 pb-12 lg:gap-16 lg:grid-cols-3 lg:pt-3 lg:pb-0" :class="skillsFlag? 'opacity-0 -z-10' : ''">
        <div class="flex flex-col gap-6 lg:col-span-2 lg:grid-cols-3 lg:grid">
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input.nav-file','data' => ['inputContent' => ['label' => 'Foto cara', 'model' => 'cara']]]); ?>
<?php $component->withName('input.nav-file'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['inputContent' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['label' => 'Foto cara', 'model' => 'cara'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input.nav-file','data' => ['inputContent' => ['label' => 'Foto cuerpo', 'model' => 'cuerpo']]]); ?>
<?php $component->withName('input.nav-file'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['inputContent' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['label' => 'Foto cuerpo', 'model' => 'cuerpo'])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            <button 
            x-bind:disabled="formSubmited"
            class="w-full p-4 py-2 mt-2 text-black uppercase transition-colors border-2 border-white lg:mt-0 saigon-bg-white lg:text-sm lg:block lg:w-full h-fit hover:bg-transparent hover:text-white"><?php echo e(__('Enviar')); ?></button>
        </div>
    </div>
    
    
</form><?php /**PATH D:\xampp\htdocs\saigon\resources\views/livewire/nav-form.blade.php ENDPATH**/ ?>