<div class="gap-4 lg:grid lg:grid-cols-3 lg:pb-24">
    <?php $__currentLoopData = $castings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <section class="pt-4 pb-8 text-right border-t-2 border-black saigon-text-white lg:text-left lg:pb-0 lg:pt-0 lg:border-t-0">
        <div class="hidden gap-2 mb-2 text-black lg:flex">
            <h2 class="saigon-text-200"><?php echo e($item['nombre']); ?> — <?php echo e($item['director']); ?> | <?php echo e($item['productora']); ?></h2>
        </div>
        
        <a href="/casting-player/<?php echo e($item['id']); ?>" class="flex flex-col justify-between bg-center bg-no-repeat bg-cover cursor-pointer h-96 lg:h-fit lg:py-28 lg:aspect-video rounded-xl" style="background-image: url('/thumbnails/<?php echo e($item['thumbnail']); ?>')">
            <div class="lg:hidden">
                <div class="pt-4 pr-4">
                    <h2 class="uppercase saigon-text-5xl"><?php echo e($item['nombre']); ?></h2>
                    <h4 class="mt-2"><?php echo e($item['director']); ?> — <?php echo e($item['productora']); ?></h4>
                </div>
            </div>
            <div class="w-12 mt-auto mb-6 ml-auto mr-4 lg:hidden">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 36 42" xml:space="preserve"><path fill="none" stroke="#F3F3F3" stroke-width="1.3" stroke-miterlimit="10" d="m34.7 20.8-17 9.8L.6 40.4V1.1l17.1 9.8z"/></svg>
            </div>
        </a>
    </section> 
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div><?php /**PATH D:\xampp\htdocs\saigon\resources\views/components/casting-grid.blade.php ENDPATH**/ ?>