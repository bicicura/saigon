<div class="relative">
    <select wire:model="<?php echo e($inputContent['model']); ?>" class="w-full uppercase bg-transparent border-none border-saigon-white text-saigon-white" name="" id="">
        <option class="" value="" disabled><?php echo e(__($inputContent['label'])); ?></option>
        <?php $__currentLoopData = $inputContent['options']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option class="text-saigon-black" value="<?php echo e($key); ?>"><?php echo e($option); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <?php $__errorArgs = [$inputContent['model']];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="absolute left-0 text-sm font-bold text-red-500 rounded-full -bottom-6 w-max"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div><?php /**PATH D:\xampp\htdocs\saigon\resources\views/components/input/nav-select.blade.php ENDPATH**/ ?>