<div x-transition.origin.center.right.duration.400ms x-show="open" class="static w-full lg:top-0 lg:left-0 lg:h-full lg:absolute bg-saigon-black lg:pt-12">
    <div class="lg:h-full">
        <div class="flex flex-col justify-between lg:h-full lg:w-9/12" style="line-height: 1.36rem;">
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.skills-group','data' => ['class' => 'saigon-text-200','inputContent' => ['model' => 'skills.deportes'],'label' => 'deportes','noHace' => 'No hace deportes','skillsGroup' => [
                'Futbol', 'Basket', 'Tenis', 'Hockey', 'Voley', 'Handball', 'Golf', 'Rugby', 'Boxeo', 'Sumo', 
                'Natacion', 'Rollers', 'Patin artistico', 'Patin sobre hielo', 'Skate', 'Longboard', 'Surf', 'Kitesurf', 'Wakeboard', 
                'Snowboard', 'Esqui', 'Equitacion', 'Polo', 'Gimnasia', 'Running', 'Ciclismo', 'Bmx', 'Yoga',
                'Pilates', 'Crossfit', 'Funcional', 'Acrobacia en piso', 'Remo', 'Parkour', 'Esgrima', 'Artes marciales', 'Tiro con arco' 
            ]]]); ?>
<?php $component->withName('skills-group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'saigon-text-200','inputContent' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['model' => 'skills.deportes']),'label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('deportes'),'noHace' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('No hace deportes'),'skillsGroup' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
                'Futbol', 'Basket', 'Tenis', 'Hockey', 'Voley', 'Handball', 'Golf', 'Rugby', 'Boxeo', 'Sumo', 
                'Natacion', 'Rollers', 'Patin artistico', 'Patin sobre hielo', 'Skate', 'Longboard', 'Surf', 'Kitesurf', 'Wakeboard', 
                'Snowboard', 'Esqui', 'Equitacion', 'Polo', 'Gimnasia', 'Running', 'Ciclismo', 'Bmx', 'Yoga',
                'Pilates', 'Crossfit', 'Funcional', 'Acrobacia en piso', 'Remo', 'Parkour', 'Esgrima', 'Artes marciales', 'Tiro con arco' 
            ])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.skills-group','data' => ['inputContent' => ['model' => 'skills.bailes'],'label' => 'bailes','noHace' => 'No baila','skillsGroup' => [
                        'Danza', 'Danza aerea', 'Baile profesional', 'Breakdance',
                        'Flamenco', 'Hip-hop', 'House', 'Jazz',
                        'Locking', 'Pole dance', 'Popping', 'Salsa',
                        'Tango', 'Tap', 'Vogue',
                        ]]]); ?>
<?php $component->withName('skills-group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['inputContent' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['model' => 'skills.bailes']),'label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('bailes'),'noHace' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('No baila'),'skillsGroup' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
                        'Danza', 'Danza aerea', 'Baile profesional', 'Breakdance',
                        'Flamenco', 'Hip-hop', 'House', 'Jazz',
                        'Locking', 'Pole dance', 'Popping', 'Salsa',
                        'Tango', 'Tap', 'Vogue',
                        ])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.skills-group','data' => ['inputContent' => ['model' => 'skills.musica'],'label' => 'musica','noHace' => 'No practica musica','skillsGroup' => [
                        'Voz', 'Guitarra acustica', 'Guitarra electrica', 'Bajo',
                        'Bateria', 'Cajon', 'Piano', 'Organo',
                        'Contrabajo', 'Violin', 'Cello', 'Trompeta',
                        'Flauta', 'Flauta traversa', 'Tuba', 'Acordeon',
                        'Saxo', 'Armonica', 'Ukelele', 'Bongo',
                        'Güiro', 'Castañuelas', 'Arpa',
                        ]]]); ?>
<?php $component->withName('skills-group'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['inputContent' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(['model' => 'skills.musica']),'label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('musica'),'noHace' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('No practica musica'),'skillsGroup' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([
                        'Voz', 'Guitarra acustica', 'Guitarra electrica', 'Bajo',
                        'Bateria', 'Cajon', 'Piano', 'Organo',
                        'Contrabajo', 'Violin', 'Cello', 'Trompeta',
                        'Flauta', 'Flauta traversa', 'Tuba', 'Acordeon',
                        'Saxo', 'Armonica', 'Ukelele', 'Bongo',
                        'Güiro', 'Castañuelas', 'Arpa',
                        ])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

            <div class="flex justify-center border-2 lg:grid-cols-3 lg:grid border-saigon-black">
                <div class="hidden lg:block"></div>
                <div class="hidden lg:block"></div>
                <div class="w-full pb-8 lg:px-0 lg:pb-0">
                    <button
                    x-on:click="$dispatch('skills-flag'); open = false"
                    type="button"
                    class="w-full p-4 py-4 mt-3 text-black transition-colors border-2 border-white lg:py-2 lg:max-w-xs lg:mt-2 saigon-bg-white lg:text-sm lg:block lg:w-full h-fit hover:bg-transparent hover:text-white">Listo</button>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH D:\xampp\htdocs\saigon\resources\views/components/skills-container.blade.php ENDPATH**/ ?>