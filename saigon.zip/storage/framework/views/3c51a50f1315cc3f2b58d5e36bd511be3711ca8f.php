

<?php $__env->startSection('title'); ?> <?php echo e('— ' . 'Mini'); ?> <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<style>
    @media (min-width: 40em) { .hero-p-w { width: 60%; } }

    @media(max-width: 800px) {
        section + section { border-top: none }
    }
</style>

<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.desktop-nav-fixed','data' => []]); ?>
<?php $component->withName('desktop-nav-fixed'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

<div class="smooth-scroll">
    <section class="px-3.5 lg:pr-16 lg:pl-10 flex flex-col-reverse lg:flex-row justify-between mb-12 lg:mb-0">

        <div class="z-20 flex flex-col items-end gap-4 mt-32 text-right lg:ml-auto lg:gap-8 lg:mt-16">
            <h1 style="width: min-content;" class="tracking-tight saigon-text-5xl saigon-font-thin saigon-title-line-height">MINI</h1>
            <div class="w-full saigon-text-300 saigon-p-line-height hero-p-w">
                <p><?php echo e(__("Esta sección dedicada a los niños y adolescentes es la más desafiante en términos de resultados y descubrimientos que vivimos en cada nueva búsqueda.")); ?></p>
                <br>
                <p><?php echo e(__("Un espacio de juego donde el talento y el carisma se despliegan sin miramientos.")); ?></p>
                <br>
                <p><?php echo e(__("Para nosotros es importante que los niños y los padres se sientan cómodos, por eso contamos con baby wranglers especializado para cada proyecto.")); ?></p>
                <br>
                <br>
                <div>
                    <p class="uppercase"><?php echo e(__('Contacto')); ?>:</p>
                    <p><span class="block lg:inline">Melanie Semhan</span><span class="hidden lg:inline lg:mx-1">  |  </span><span class="block lg:inline">mini@saigonbuenosaires.com</span></p>
                </div>
            </div>
        </div>
    
    </section>
    
    <section class="px-3.5 lg:pr-16 lg:pl-10 lg:pt-8 lg:mt-0">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('casting-list', ['seccion' => $seccion])->html();
} elseif ($_instance->childHasBeenRendered('KJRuSJF')) {
    $componentId = $_instance->getRenderedChildComponentId('KJRuSJF');
    $componentTag = $_instance->getRenderedChildComponentTagName('KJRuSJF');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('KJRuSJF');
} else {
    $response = \Livewire\Livewire::mount('casting-list', ['seccion' => $seccion]);
    $html = $response->html();
    $_instance->logRenderedChild('KJRuSJF', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </section>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\saigon\resources\views/mini.blade.php ENDPATH**/ ?>