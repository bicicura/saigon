<div class="flex items-center gap-4 <?php echo e($attributes['reverse']); ?>">
    <label class="lg:order-last" for="<?php echo e($inputContent['label']); ?>"><?php echo e(__($inputContent['label'])); ?></label>
    <input class="bg-transparent border-white cursor-pointer lg:order-first border-px focus:ring-0" wire:model="<?php echo e($inputContent['model']); ?>" value="<?php echo e($inputContent['label']); ?>" type="radio" name="" id="<?php echo e($inputContent['label']); ?>">
</div><?php /**PATH D:\xampp\htdocs\saigon\resources\views/components/input/nav-checkbox.blade.php ENDPATH**/ ?>