<div class="lg:w-full">
    <div class="relative lg:mb-2">
        <label class="cursor-pointer" for="<?php echo e($inputContent['model']); ?>"><?php echo e($inputContent['label']); ?></label>
        <span class="hidden w-full text-sm text-right lg:text-left lg:inline"><?php echo e($inputContent['legend']); ?></span>
        <?php $__errorArgs = [$inputContent['model']];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="absolute left-0 text-sm font-bold text-red-500 rounded-full top-6 w-max"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <input type="text" wire:model="<?php echo e($inputContent['model']); ?>" id="<?php echo e($inputContent['model']); ?>" class="w-full text-right text-white bg-transparent border-none lg:text-left focus:ring-0">
    <p class="pt-3 text-lg leading-snug lg:border-t lg:hidden"><?php echo e($inputContent['legend']); ?></p>
</div><?php /**PATH D:\xampp\htdocs\saigon\resources\views/components/input/nav-input-text-legend.blade.php ENDPATH**/ ?>