<div class="flex flex-col justify-center gap-8 p-5 text-left lg:p-0 lg:flex-row">
    <div class="w-40">
        <p class="uppercase"><?php echo e($label); ?></p>
    </div>
    <div class="grid w-full grid-cols-2 gap-8 lg:grid-cols-4 lg:gap-0 lg:gap-x-6">
        <div class="flex items-center gap-2 lg:col-span-4">
            <input wire:model="<?php echo e($label); ?>" wire:click="skillClicked('<?php echo e($label); ?>')" class="bg-transparent border-white cursor-pointer lg:order-first border-px focus:ring-0" value="no-<?php echo e($label); ?>" type="checkbox" id="no-<?php echo e($label); ?>">
            <label for="no-<?php echo e($label); ?>" class="uppercase" ><?php echo e(__($noHace)); ?></label>
        </div>
        <?php $__currentLoopData = $skillsGroup; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="flex items-center gap-2" wire:key="<?php echo e($loop->index); ?>">
                <input wire:model="<?php echo e($inputContent['model']); ?>" class="bg-transparent border-white cursor-pointer lg:order-first border-px focus:ring-0" value="<?php echo e($skill); ?>" type="checkbox" id="<?php echo e($label); ?>-<?php echo e($loop->index); ?>">
                <label for="<?php echo e($label); ?>-<?php echo e($loop->index); ?>" class="uppercase"><?php echo e(__($skill)); ?></label>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div><?php /**PATH D:\xampp\htdocs\saigon\resources\views/components/skills-group.blade.php ENDPATH**/ ?>