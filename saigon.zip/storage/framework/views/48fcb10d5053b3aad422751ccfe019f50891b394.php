

<?php $__env->startSection('content'); ?>

<style>
    @media (min-width: 40em) { .hero-p-w { width: 45%; } }
</style>

<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.desktop-nav-fixed','data' => []]); ?>
<?php $component->withName('desktop-nav-fixed'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

<section class="px-3.5 lg:pr-16 lg:pl-10 flex flex-col-reverse lg:flex-row justify-between mb-12">

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.section-hero','data' => ['title' => 'CASTINGS COMERCIALES','description' => 'Realizamos servicios de casting para proyectos comerciales nacionales e internacionales. Nuestro estudio esta equipado con varias salas y contamos con un staff altamente capacitado y competente. Tenemos un abordaje integral, mas de diez años de experiencia trabajando con productoras, lo que nos da la excelencia que requiere el mercado publicitario.']]); ?>
<?php $component->withName('section-hero'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('CASTINGS COMERCIALES'),'description' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Realizamos servicios de casting para proyectos comerciales nacionales e internacionales. Nuestro estudio esta equipado con varias salas y contamos con un staff altamente capacitado y competente. Tenemos un abordaje integral, mas de diez años de experiencia trabajando con productoras, lo que nos da la excelencia que requiere el mercado publicitario.')]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

</section>

<section class="px-3.5 lg:pr-16 lg:pl-10 pt-20 lg:mt-0">
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.casting-grid','data' => ['castings' => $castings]]); ?>
<?php $component->withName('casting-grid'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['castings' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($castings)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\saigon\resources\views/comerciales.blade.php ENDPATH**/ ?>