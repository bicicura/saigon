
<div class="splide">
    <div class="flex items-center justify-between mb-2 saigon-text-500 splide__arrows">
        <p class="leading-none"><span class="uppercase">{{$item['nombre']}}</span> — {{$item['director']}} | {{$item['productora']}}</p>
        <div class="flex ml-auto w-max">
            <button style="position: static" class="splide__arrow splide__arrow--prev saigon-font-light">
                <
            </button>
            <button style="position: static" class="splide__arrow splide__arrow--next saigon-font-light">
                >
            </button>
        </div>
    </div>

    <div class="overflow-hidden splide__track aspect-video rounded-2xl">
          <ul class="splide__list">
              <li class="splide__slide">
                <div>
                    <img class="object-cover cursor-grab rounded-2xl carusel-img" src="/imgs/fotografia/1.png" alt="">
                </div>
              </li>
              <li class="splide__slide">
                <div>
                    <img class="object-cover cursor-grab rounded-2xl carusel-img" src="/imgs/fotografia/2.png" alt="">
                </div>
              </li>
              <li class="splide__slide">
                <div>
                    <img class="object-cover cursor-grab rounded-2xl carusel-img" src="/imgs/fotografia/3.png" alt="">
                </div>
              </li>
          </ul>
    </div>
  </div>