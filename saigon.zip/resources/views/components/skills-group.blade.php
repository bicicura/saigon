<div class="flex flex-col justify-center gap-8 p-5 text-left lg:p-0 lg:flex-row">
    <div class="w-40">
        <p class="uppercase">{{$label}}</p>
    </div>
    <div class="grid w-full grid-cols-2 gap-8 lg:grid-cols-4 lg:gap-0 lg:gap-x-6">
        <div class="flex items-center gap-2 lg:col-span-4">
            <input wire:model="{{$label}}" wire:click="skillClicked('{{$label}}')" class="bg-transparent border-white cursor-pointer lg:order-first border-px focus:ring-0" value="no-{{$label}}" type="checkbox" id="no-{{$label}}">
            <label for="no-{{$label}}" class="uppercase" >{{__($noHace)}}</label>
        </div>
        @foreach ($skillsGroup as $skill)
            <div class="flex items-center gap-2" wire:key="{{ $loop->index }}">
                <input wire:model="{{$inputContent['model']}}" class="bg-transparent border-white cursor-pointer lg:order-first border-px focus:ring-0" value="{{$skill}}" type="checkbox" id="{{$label}}-{{ $loop->index }}">
                <label for="{{$label}}-{{ $loop->index }}" class="uppercase">{{__($skill)}}</label>
            </div>
        @endforeach
    </div>
</div>