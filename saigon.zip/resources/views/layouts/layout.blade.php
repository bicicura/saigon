@include('layouts.header')
    
    <main class="lg:ml-auto">
        @yield('content')
    </main>

@include('layouts.footer')
